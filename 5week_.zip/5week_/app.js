// 공통 동작: 하단 탭 표시 · 탭/패널 전환 · 재료 칩 · TOP 버튼 (와이어프레임용 최소 동작)
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

// 1) 현재 페이지에 맞는 하단 탭 강조 (body의 data-page 값 기준)
const TAB_OF = { home: 'home', list: 'list', detail: 'list', empty: 'list', my: 'my' };
const page = document.body.dataset.page;
$$('.tabbar a').forEach(a => a.classList.toggle('on', a.dataset.tab === TAB_OF[page]));

// 2) 페이지 안의 탭(목록 배지 · 마이 탭) 전환
document.addEventListener('click', e => {
  const t = e.target.closest('[data-tab-btn]');
  if (!t) return;
  const wrap = t.closest('.screen');
  $$('.tabs button', wrap).forEach(b => b.classList.toggle('on', b === t));
  $$('.pane', wrap).forEach(p => p.classList.toggle('on', p.dataset.pane === t.dataset.tabBtn));
});

// 3) 홈: 재료 칩을 누르면 삭제, 2개 미만이면 검색 버튼 비활성
const mine = $('#mine');
const find = $('#find');
if (mine && find) {
  const syncFind = () => { find.disabled = $$('.chip', mine).length < 2; };
  mine.addEventListener('click', e => {
    if (e.target.classList.contains('chip')) { e.target.remove(); syncFind(); }
  });
  find.addEventListener('click', () => { if (!find.disabled) location.href = 'list.html'; });
  syncFind();
}

// 4) TOP 버튼
const topBtn = $('.totop');
if (topBtn) {
  addEventListener('scroll', () => topBtn.classList.toggle('show', scrollY > 200));
  topBtn.addEventListener('click', () => scrollTo({ top: 0, behavior: 'smooth' }));
}
